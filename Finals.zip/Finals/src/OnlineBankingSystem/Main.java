package OnlineBankingSystem;

public class Main {
    public static void main(String[] args) {
        // Initialize accounts and set up initial system state
        Finals.initializeAccounts();

        // Start the online banking system
        Finals.start();
    }
}
