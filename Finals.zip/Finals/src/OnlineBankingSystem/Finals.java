package OnlineBankingSystem;

import java.util.HashMap;
import java.util.Scanner;

public class Finals {
    private static HashMap<String, Account> accounts = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);
    private static Account currentAccount;

   public static void initializeAccounts() {
    // Adding an account with the new fields for favorite color and security answer
    accounts.put("user1", new Account(
        "user1",               // Username
        "John Doe",            // Full name
        "01-01-1990",          // Birthday
        "City A",              // Birthplace
        "Address 1",           // Address
        "123-456-7890",        // Mobile number
        "Savings",             // Account type
        "pass123",             // Password
        1000.00,               // Initial balance
        "Blue",                // Favorite color (new field)
        "City A"               // Security answer (birthplace)
    ));
}


    public static void start() {
        System.out.println("Welcome to the Online Banking System!");
        boolean loggedIn = false;

        while (!loggedIn) {
            System.out.println("\n1. Login");
            System.out.println("2. Register");
            System.out.println("3. Forgot Password");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    loggedIn = login();
                    break;
                case 2:
                    register();
                    break;
                case 3:
                    forgotPassword();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        mainMenu();
    }

    public static boolean login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        Account account = accounts.get(username);
        if (account != null && account.checkPassword(password)) {
            System.out.println("Login successful!");
            clearScreen(); // Clear screen after login
            currentAccount = account;
            return true;
        } else {
            System.out.println("Invalid username or password.");
            return false;
        }
    }

    public static void register() {
        System.out.print("Enter a new username: ");
        String username = scanner.nextLine();

        if (accounts.containsKey(username)) {
            System.out.println("Username already exists. Please try a different one.");
            return;
        }

        System.out.print("Enter full name: ");
        String fullName = scanner.nextLine();

        System.out.print("Enter birthday (e.g., DD-MM-YYYY): ");
        String birthday = scanner.nextLine();

        System.out.print("Enter birthplace: ");
        String birthplace = scanner.nextLine();

        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        System.out.print("Enter mobile number: ");
        String mobileNumber = scanner.nextLine();

        System.out.print("Choose account type (Savings or Current): ");
        String accountType = scanner.nextLine();

        String password = promptForPassword();

        // Ask security questions
        System.out.println("FOR SECURITY QUESTIONS: ");
        System.out.print("What is your favorite color? ");
        String favoriteColor = scanner.nextLine();

        System.out.print("What is the name of your birthplace? ");
        String securityAnswer = scanner.nextLine();

        System.out.print("Enter initial deposit amount: ");
        double balance = scanner.nextDouble();
        scanner.nextLine();

        if (balance < 0) {
            System.out.println("Initial deposit cannot be negative. Registration failed.");
            return;
        }

        Account newAccount = new Account(username, fullName, birthday, birthplace, address, mobileNumber, accountType, password, balance, favoriteColor, securityAnswer);
        accounts.put(username, newAccount);

        System.out.println("Registration successful! Here are your account details:");
        System.out.println("Username: " + username);
        System.out.println("Account Number: " + newAccount.getAccountNumber());
        System.out.println("Account Type: " + newAccount.getAccountType());
    }

    // Method to prompt for password with asterisks (masked input)
    public static String promptForPassword() {
        System.out.print("Enter a new password: ");
        char[] password = new char[20];
        int i = 0;
        while (true) {
            try {
                char ch = (char) System.in.read();
                if (ch == '\n') break;
                if (ch != '\r') {
                    password[i++] = ch;
                    System.out.print('*');
                }
            } catch (Exception e) {
                break;
            }
        }
        return new String(password, 0, i);
    }

    // Forgot password feature
    public static void forgotPassword() {
        System.out.print("Enter username to reset password: ");
        String username = scanner.nextLine();
        Account account = accounts.get(username);

        if (account == null) {
            System.out.println("Username not found.");
            return;
        }

        System.out.print("What is your favorite color? ");
        String colorAnswer = scanner.nextLine();
        System.out.print("What is the name of your birthplace? ");
        String birthplaceAnswer = scanner.nextLine();

        if (account.getFavoriteColor().equalsIgnoreCase(colorAnswer) && account.getSecurityAnswer().equalsIgnoreCase(birthplaceAnswer)) {
            System.out.print("Security answers are correct. Enter a new password: ");
            String newPassword = scanner.nextLine();
            account.setPassword(newPassword);
            System.out.println("Password has been successfully reset.");
        } else {
            System.out.println("Incorrect answers to security questions.");
        }
    }

    // Clear the console screen
    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void mainMenu() {
        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Show Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer Money");
            System.out.println("5. Pay Bills");
            System.out.println("6. Logout");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume leftover newline

            switch (choice) {
                case 1:
                    showBalance();
                    break;
                case 2:
                    System.out.print("Enter deposit amount: ");
                    double depositAmount = scanner.nextDouble();
                    currentAccount.deposit(depositAmount);
                    break;
                case 3:
                    System.out.print("Enter withdrawal amount: ");
                    double withdrawalAmount = scanner.nextDouble();
                    currentAccount.withdraw(withdrawalAmount);
                    break;
                case 4:
                    transferMoney();
                    break;
                case 5:
                    payBills();
                    break;
                case 6:
                    System.out.println("Logging out... Thank you for using our banking system.");
                    currentAccount = null;
                    start();  // Return to login screen after logging out
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void transferMoney() {
        System.out.print("Enter recipient username: ");
        String recipientUsername = scanner.next();
        System.out.print("Enter transfer amount: ");
        double transferAmount = scanner.nextDouble();

        Account recipient = accounts.get(recipientUsername);
        if (recipient != null) {
            System.out.printf("\nTransfer Preview:\nRecipient Account Number: %s\nAmount: %.2f\n", recipient.getAccountNumber(), transferAmount);
            System.out.print("Confirm transfer? (yes/no): ");
            String confirmation = scanner.next();

            if (confirmation.equalsIgnoreCase("yes")) {
                if (transferAmount > 0 && transferAmount <= currentAccount.getBalance()) {
                    currentAccount.transfer(recipient, transferAmount);
                } else {
                    System.out.println("Invalid amount or insufficient balance.");
                }
            } else {
                System.out.println("Transfer canceled.");
            }
        } else {
            System.out.println("Recipient account not found.");
        }
    }

    private static void payBills() {
        System.out.println("\nBills Payment Menu:");
        System.out.println("1. Electricity Bill");
        System.out.println("2. Water Bill");
        System.out.println("3. Internet Bill");
        System.out.print("Choose a bill to pay: ");
        int billChoice = scanner.nextInt();
        scanner.nextLine();  // Consume leftover newline

        String billType = null;  // Initialize billType

        switch (billChoice) {
            case 1:
                billType = "Electricity Bill";
                break;
            case 2:
                billType = "Water Bill";
                break;
            case 3:
                billType = "Internet Bill";
                break;
            default:
                System.out.println("Invalid bill type. Payment canceled.");
                return;  // Return early if invalid choice
        }

        // Proceed with the bill payment process
        System.out.print("Enter biller name: ");
        String billerName = scanner.nextLine();

        System.out.print("Enter account number for payment: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter amount to pay: ");
        double amount = scanner.nextDouble();

        System.out.printf("\nPayment Preview:\nBiller: %s\nBill Type: %s\nAccount Number: %s\nAmount: %.2f\n", billerName, billType, accountNumber, amount);
        System.out.print("Confirm payment? (yes/no): ");
        String confirmation = scanner.next();

        if (confirmation.equalsIgnoreCase("yes")) {
            if (amount > 0 && amount <= currentAccount.getBalance()) {
                currentAccount.withdraw(amount);
                System.out.println("Bill payment successful!");
            } else {
                System.out.println("Invalid amount or insufficient balance.");
            }
        } else {
            System.out.println("Payment canceled.");
        }
    }

    // Show balance and calculate interest
public static void showBalance() {
    double balance = currentAccount.getBalance();
    double balanceAfter1Month = balance;  // Store the current balance as the starting balance for after 1 month
    double interest = 0.0;

    // Check if balance is greater than or equal to 5000
    if (balance >= 5000) {
        interest = balance * 0.00125;  // 0.125% interest for 1 month
        balanceAfter1Month = balance + interest;  // Add interest to balance for next month
    }

    // Display current balance
    System.out.printf("Your current balance is: %.2f\n", balance);

    // Display balance after 1 month
    System.out.printf("Balance after 1 month: %.2f\n", balanceAfter1Month);

    // If interest is applied, show it
    if (interest > 0) {
        System.out.printf("Interest after 1 month: %.2f\n", interest);
    } else {
        System.out.println("Interest will not be applied as the balance is below 5,000.");
    }
}
}
