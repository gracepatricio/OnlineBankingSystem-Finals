package OnlineBankingSystem;

public class Account {
    private String username;
    private String fullName;
    private String birthday;
    private String birthplace;
    private String address;
    private String mobileNumber;
    private String accountType;
    private String password;
    private double balance;
    private String accountNumber;
    private String favoriteColor;  // New field for favorite color
    private String securityAnswer; // New field for security question (birthplace)

    public Account(String username, String fullName, String birthday, String birthplace, String address, String mobileNumber, 
                   String accountType, String password, double balance, String favoriteColor, String securityAnswer) {
        this.username = username;
        this.fullName = fullName;
        this.birthday = birthday;
        this.birthplace = birthplace;
        this.address = address;
        this.mobileNumber = mobileNumber;
        this.accountType = accountType;
        this.password = password;
        this.balance = balance;
        this.accountNumber = generateAccountNumber();
        this.favoriteColor = favoriteColor;   // Initialize favorite color
        this.securityAnswer = securityAnswer; // Initialize security question answer
    }

    // Getter and setter methods for the new fields
    public String getFavoriteColor() {
        return favoriteColor;
    }

    public void setFavoriteColor(String favoriteColor) {
        this.favoriteColor = favoriteColor;
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }

    // Method to check if the entered password matches the stored password
    public boolean checkPassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    // Setter method for password (used for password reset)
    public void setPassword(String newPassword) {
        this.password = newPassword;
    }

    // Getter methods for other fields
    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return fullName;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getBirthplace() {
        return birthplace;
    }

    public String getAddress() {
        return address;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public double getBalance() {
        return balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    // Method to generate a random account number (you can customize this)
    private String generateAccountNumber() {
        return "ACCT" + (int)(Math.random() * 1000000); // Example account number generator
    }

    // Method to deposit money into the account
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited " + amount + " to your account. New balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Method to withdraw money from the account
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew " + amount + " from your account. New balance: " + balance);
        } else {
            System.out.println("Invalid withdrawal amount or insufficient balance.");
        }
    }

    // Method to transfer money to another account
    public void transfer(Account recipient, double amount) {
        if (amount > 0 && amount <= balance) {
            withdraw(amount);
            recipient.deposit(amount);
            System.out.println("Transferred " + amount + " to " + recipient.getUsername());
        } else {
            System.out.println("Invalid transfer amount or insufficient balance.");
        }
    }
}
